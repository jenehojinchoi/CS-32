//
//  memleak_test.cpp
//  Project2
//
//  Created by Jene Hojin Choi on 2021/07/16.
//

#include "OnlineDating.h"
#include "memleak.h"
#include <iostream>
#include <cassert>

using namespace std;

void test()
{
    cerr << "test A" << endl;
    OnlineDating s;
    cerr << "test B" << endl;
    s.makeMatch("Higby", "Venus", IntWrapper(10));
    cerr << "test C" << endl;
    s.makeMatch("Vanu", "Excelsior", IntWrapper(20));
    cerr << "test D" << endl;
    OnlineDating s2;
    cerr << "test E" << endl;
    s2.makeMatch("Col", "Sigma", IntWrapper(30));
    cerr << "test F" << endl;
    s2 = s;
    cerr << "test G" << endl;
    s2.makeMatch("Eggsy", "Bouillion", IntWrapper(40));
    cerr << "test H" << endl;
}

int main()
{
    test();
    cerr << "DONE" << endl;
}
